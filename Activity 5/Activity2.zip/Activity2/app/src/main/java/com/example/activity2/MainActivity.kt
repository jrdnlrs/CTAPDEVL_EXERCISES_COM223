package com.example.activity2

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.activity2.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val validUsername = "jrdnlrs"  // Predefined username
    private val validPassword = "Arsenex012"  // Predefined password

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge setup should come first
        enableEdgeToEdge()

        // View binding initialization
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Apply window insets for edge-to-edge
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    
        // Login button click listener
        binding.btnLogin.setOnClickListener {
            val username = binding.edtxtUsername.text.toString()
            val password = binding.edtxtPassword.text.toString()

            if (username == validUsername && password == validPassword) {
                // Successful login - navigate to HomePage
                startActivity(Intent(this, HomePage::class.java))
                // Optional: finish() to prevent returning to login screen with back button
            } else {
                // Show error message
                Toast.makeText(
                    this,
                    "Invalid username or password",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}