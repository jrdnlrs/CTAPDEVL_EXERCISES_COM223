package com.example.activity2

import com.example.activity2.Post

object db {
    val posts = mutableListOf<Post>()

    init {
        posts.add(Post("Jrdnlrs", "First Post!", R.drawable.jah))
        posts.add(Post("Sophia", "Rehearsals Done ", R.drawable.sophia))
        posts.add(Post("Nintendo", "Peach in Chrome, Nintendo Switch 2 Out Now.", R.drawable.peach))
    }

    fun addPost(post: Post) {
        posts.add(post)
    }

    fun getAllPosts(): List<Post> {
        return posts
    }
}
