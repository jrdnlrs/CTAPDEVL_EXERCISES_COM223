package com.example.activity2

data class Post(
    val name: String,
    val content: String,
    val imageResId: Int



)