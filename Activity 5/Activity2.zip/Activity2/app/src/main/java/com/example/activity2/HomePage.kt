package com.example.activity2

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class HomePage : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_page)

        // Initialize fragments
        val homeFragment = HomeFeedFragment()
        val profileFragment = ProfileFragment()
        val notificationsFragment = NotificationsFragment()

        // Set initial fragment
        setCurrentFragment(homeFragment)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        bottomNavigationView.setOnItemSelectedListener { item ->
            when(item.itemId) {
                R.id.home -> setCurrentFragment(homeFragment)
                R.id.notifications -> setCurrentFragment(notificationsFragment)
                R.id.profile -> setCurrentFragment(profileFragment)
            }
            true
        }

        // Setup notification badge
        bottomNavigationView.getOrCreateBadge(R.id.notifications).apply {
            number = 10
            isVisible = true
        }

    }

    private fun setCurrentFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.flfragment, fragment)
            .commit()
    }
}