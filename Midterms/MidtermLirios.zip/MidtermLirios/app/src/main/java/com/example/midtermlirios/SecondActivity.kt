package com.example.midtermlirios
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        val firstInput = intent.getStringExtra("input1")

        val displayInputOne = findViewById<TextView>(R.id.displayInput1)
        displayInputOne.text = "$firstInput"

        val btnToThird = findViewById<Button>(R.id.buttonToThird)

        btnToThird.setOnClickListener {
            val secondIntent = Intent(this, ThirdActivity::class.java)
            secondIntent.putExtra("input2", firstInput)
            startActivity(secondIntent)
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Activity 2 Start", "Activity 2 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Activity 2 Resume", "Activity 2 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Activity 2 Pause", "Activity 2 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Activity 2 Stop", "Activity 2 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Activity 2 Destroy", "Activity 2 has been destroyed")
    }
}